<?php 


include 'config.php';
if (isset($_GET['id'])) {
	$post = mysqli_real_escape_string($conn, $_GET['id']); 
     
    
}
else {
    header('location:index.php');
}


$query = "SELECT * FROM photos s 
            WHERE s.id = '$post' ";
$run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
if (mysqli_num_rows($run_query) > 0 ) {
while ($row = mysqli_fetch_array($run_query)) {

        $post_id = $row['id'];
        $post_slika = $row['url'];    
        
        }
    }

    $pic = '../'.$post_slika;
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.ckeditor.com/ckeditor5/10.0.1/classic/ckeditor.js"></script>
    <script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
</head>
<body>
    <div>
    <?php 
       if (isset($_POST['update'])) {


        
        $image = $_FILES['image']['name'];
        $ext = $_FILES['image']['type'];
        $validExt = array ("image/gif",  "image/jpeg",  "image/pjpeg", "image/png");
        if (empty($image)) {
            $picture = $post_image;
        }
        else if ($_FILES['image']['size'] <= 0 || $_FILES['image']['size'] > 1024000 )
        {
            echo "<script>alert('Image size is not proper');
            window.location.href = 'editpost.php?id=$id';</script>";
        
        }
        else if (!in_array($ext, $validExt)){
            echo "<script>alert('Not a valid image');
            window.location.href = 'editpost.php?id=$id';</script>";
        exit();
        }
        else {
            $folder  = '../img/gallery/'; //folder u koji se sprema
            $imgext = strtolower(pathinfo($image, PATHINFO_EXTENSION) );
            $picture = rand(1000 , 1000000) .'.'.$imgext;
            move_uploaded_file($_FILES['image']['tmp_name'], $folder.$picture);
            $path = 'img/gallery/' . $picture; //url koji se sprema u bazu
        }

      
            $queryupdate = "UPDATE photos SET  url= '$path' WHERE id= '$post_id' " ;
            $result = mysqli_query($conn , $queryupdate) or die(mysqli_error($conn));
            $check = mysqli_affected_rows($conn);

            if ($check>0) {
                session_start();
                $_SESSION['flash_message'] = "POST SUCCESSFULLY UPDATED";
                header("location: index.php");

               

               
            }
            else {
                $msg = "Error: try again";
                ?><p style="text-align: center;border-radius: 4px;border: 2px solid red;background-color: #f87;margin: 1rem auto;padding:0.5rem;font-weight: 800;color:red;"><?=$msg ?></p>   <?php
    }
    
    
    
    
    }

    ?>
    


    <h1 style="text-align: left;">Uredi objavu</h1>
    <b id="mesg"></b>
    <br>
    <form role="form" method="POST" enctype="multipart/form-data" id=user_form>
    

    <br>
    <p>Trenutna slika</p>
    <div class="form-group">
    
		<img id="novaslika" class="img-responsive" width="250" height="150px" src="<?php echo $pic; ?>" alt="Photo">
        <br>
		
    </div>
    
    <input type="file" name="image" onChange="openfile(event)"> 
    <script>
        var openfile = function(event){
            var input = event.target;
            var reader = new FileReader();
            reader.onload  =  function(){
                var dataurl = reader.result;
                var output = document.querySelector("#novaslika");
                output.src = dataurl;

            }
            reader.readAsDataURL(input.files[0]);

        }
    </script>
    
  
    </div>
    <br>
    <br>
    <input type="submit" value="Spremi promjene" id="update"  name="update">
<script>
    ClassicEditor
        .create( document.querySelector( '#text' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
    
  

    </form>

    <br>
    <br>
    <br>
    <div>
    
    <button> <a class="linkback" href="index.php">Povratak nazad</a> </button>
   
</body>
</html>  


    
    
    



