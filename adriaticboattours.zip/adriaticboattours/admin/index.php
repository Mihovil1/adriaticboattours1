<?php
session_start();
include 'config.php';
// Initialize the session

 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body{ font: 14px sans-serif; text-align: center; }
    </style>
    
</head>
<span style="float:right;margin-right:8px;margin-top:5px;"><a href="logout.php" >Sign Out</a></span><br/>

<body>

    
    
<div class="row" style="margin:auto;width:700px;margin-top:25px;">
        
        <?php
        
        if(isset($_SESSION['flash_message'])) {
            $message = $_SESSION['flash_message'];
            unset($_SESSION['flash_message']); 
            ?><p style="text-align: center;border-radius: 4px;border: 2px solid green;background-color: #afa;margin: 1rem auto;padding:0.5rem;font-weight: 800;color:green;"><?=$message ?></p>   <?php
        }
        
        ?>

            <table>


            
                    <tr >
                        <th>Naslov</th>
                        <th>Paragraf</th>
                        <th>Slika</th>                  
                        <th>Status</th>
                        <th>Pregled objave</th>
                        <th>Uredi</th>
                        <th>Izbriši</th>
                        <th>Objavi</th>
                       
                        
                     </tr>

        <?php

            $query = "SELECT * from photos s
            JOIN tekst t on t.position = s.position
            WHERE t.position   NOT LIKE 'about%' ";
            $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
            if (mysqli_num_rows($run_query) > 0 ) {
            while ($row = mysqli_fetch_array($run_query)) {
                $post_id = $row['id'];
                $post_heading = $row['heading'];
                $post_paragraph = $row['paragraph'];
                $post_picture = $row['url'];
                $post_pozicija = $row['position'];
                $post_status = $row['visible'];
                
                if($post_status == '0'){
                   
                    $post_status = 'izbrisano';
                    
                }elseif($post_status == '1'){
                    $post_status = 'objavljeno';
                    
                }

                $pic = '../'.$post_picture;

                echo "<tr>";
                echo "<td>$post_heading</td>";
                echo "<td>".substr($post_paragraph,0,15)."...</td>";
                echo "<td><img  width='100' src='$pic' alt='Post Image' ></td>";
               
                echo "<td>$post_status</td>";
                
                echo "<td><a href='post.php?post=$post_id' style='color:green'>Vidi objavu</a></td>";
                echo "<td><a href='editpost.php?id=$post_id'><span class='glyphicon glyphicon-edit' style='color: #;'>Uredi</span></a></td>";
                echo "<td><a onClick=\"javascript: return confirm('Are you sure you want to delete this post?')\" href='?del=$post_id'><i class='fa fa-times' style='color: red;'></i>Izbriši</a></td>";
                echo "<td><a onClick=\"javascript: return confirm('Are you sure you want to publish this post?')\"href='?pub=$post_id'><i class='fa fa-times' style='color: red;'></i>Objavi</a></td>";

                echo "</tr>";

            }
            }
            else {
                echo "<script>alert('Not any news yet! Start Posting now');
                window.location.href= 'publishnews.php';</script>";
            }

        ?>
         </table>

    
    <?php
    if (isset($_GET['del'])) {
        $post_del = mysqli_real_escape_string($conn, $_GET['del']);
        $del_query = "UPDATE tekst set visible=0
        WHERE id='$post_del'";
        $del_query2 = "UPDATE photos set visible=0
        WHERE id='$post_del'";
        $run_del_query = mysqli_query($conn, $del_query) or die (mysqli_error($conn));
        $run_del_query2 = mysqli_query($conn, $del_query2) or die (mysqli_error($conn));
        
        if (mysqli_affected_rows($conn) > 0) {
            echo "<script>alert('post deleted successfully');
            window.location.href='index.php';</script>";
        }
        else {
         echo "<script>alert('error occured.try again!');</script>";   
        }
        }

        if (isset($_GET['pub'])) {
            $post_pub = mysqli_real_escape_string($conn,$_GET['pub']);
            $pub_query = "UPDATE photos SET visible='1' WHERE id='$post_pub'";
            $pub_query2 = "UPDATE tekst SET visible='1' WHERE id='$post_pub'";
    
            $run_pub_query = mysqli_query($conn, $pub_query) or die (mysqli_error($conn));
            $run_pub_query = mysqli_query($conn, $pub_query2) or die (mysqli_error($conn));
            if (mysqli_affected_rows($conn) > 0) {
                echo "<script>alert('post published successfully');
                window.location.href='index.php';</script>";
            }
            else {
             echo "<script>alert('error occured.try again!');</script>";   
            }
            }
    
            include 'indexMeni.php';
            include 'galerija.php';
    ?>
    

  
        
       
    
</body>
</html>

