<div class="row" style="margin:auto;width:500px;margin-top:50px;">
<br>
<br>
<h3 style="text-align:center;margin: auto;width:700px;">Galerija</h3>
        
        <?php
        
        if(isset($_SESSION['flash_message'])) {
            $message = $_SESSION['flash_message'];
            unset($_SESSION['flash_message']); 
            ?><p style="text-align: center;border-radius: 4px;border: 2px solid green;background-color: #afa;margin: 1rem auto;padding:0.5rem;font-weight: 800;color:green;"><?=$message ?></p>   <?php
        }

        ?>

            <table>


            
                    <tr >
                        <th>Slika</th>                       
                        <th>Status</th>
                        <th>Pregled objave</th>
                        <th>Uredi</th>
                        <th>Izbriši</th>
                        <th>Objavi</th>
                       
                        
                     </tr>

        <?php

            $query = "SELECT * FROM photos s
            WHERE s.position LIKE 'galerija%' ";
            $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
            if (mysqli_num_rows($run_query) > 0) {
            while ($row = mysqli_fetch_array($run_query)) {
                $post_id = $row['id'];
                $post_picture = $row['url'];
                $post_pozicija = $row['position'];
                $post_status = $row['visible'];
                
                if($post_status == '0'){
                   
                    $post_status = 'izbrisano';
                    
                }elseif($post_status == '1'){
                    $post_status = 'objavljeno';
                    
                }

                $pic = '../'.$post_picture;


                echo "<tr>";
                echo "<td><img  width='100' src='$pic' alt='Post Image' ></td>";
                echo "<td>$post_status</td>";
                
                echo "<td><a href='postGalerija.php?post=$post_id' style='color:green'>Vidi objavu</a></td>";
                echo "<td><a href='editpostGalerija.php?id=$post_id'><span class='glyphicon glyphicon-edit' style='color: #;'>Uredi</span></a></td>";
                echo "<td><a onClick=\"javascript: return confirm('Are you sure you want to delete this post?')\" href='?del=$post_id'><i class='fa fa-times' style='color: red;'></i>Izbriši</a></td>";
                echo "<td><a onClick=\"javascript: return confirm('Are you sure you want to publish this post?')\"href='?pub=$post_id'><i class='fa fa-times' style='color: red;'></i>Objavi</a></td>";

                echo "</tr>";

            }
            }
            else {
                echo "<script>alert('Not any news yet! Start Posting now');
                window.location.href= 'publishnews.php';</script>";
            }

        ?>
         </table>