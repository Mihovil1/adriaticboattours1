<?php 

include 'config.php';

if (isset($_GET['post'])) {
	$post = mysqli_real_escape_string($conn, $_GET['post']); 
     
    
}

else {
    header('location:index.php');
}

$query = "SELECT * FROM photos s
        JOIN tekst t on s.position = t.position
        WHERE t.id = '$post' ";
$run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));

if (mysqli_num_rows($run_query) > 0 ) {
while ($row = mysqli_fetch_array($run_query)) {
            
            $post_heading = $row['heading'];
            $post_paragraph = $row['paragraph'];
            $post_picture = $row['url'];
  
        
        }
    
       
}
    $pic = '../'.$post_picture;
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
</body>
</html>

<h1><?php echo $post_heading; ?></h1>


<hr>
<img  class="center" src="<?php echo $pic; ?>" alt="900 * 300">
<hr>

<br>

<h3><?php echo  $post_paragraph ?></h3>

<div style="text-align:center;">
    <button> <a class="linkback" href="index.php">Povratak nazad</a> </button>
    
</div>