<?php
$servername = "localhost";
$username = "adriat13";
$password = "W4f7zvJq65";
$db = "adriat13_adriaticboattours";

// Create connection
$conn = mysqli_connect($servername,$username,$password,$db);
$conn->set_charset('utf8mb4');
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
  }
 