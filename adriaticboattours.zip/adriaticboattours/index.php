<?php
include_once 'header-footer/header.php';
include_once 'baza/database.php';


$sql = "SELECT * FROM tekst WHERE position = 'naslovi'
ORDER by id; " ;
$result = mysqli_query($con, $sql);
while($row = mysqli_fetch_array($result)){
	$array = [];
	foreach ($result as $row){
	$array[] = $row['heading'];
  
	}
	
}

?>
<style>
<?php include 'css/style.css'; ?>
</style>

  <section id="about" class="about-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="box-shadow-full">
            <div class="row">
              <div class="col-md-6">
                <div class="row">
                  <div class="col-sm-6 col-md-5">
                    <div class="about-img">
                    <?php
                    $sql = "SELECT * from photos p 
                    WHERE p.position LIKE '%ABOUT%'
                    AND p.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
                    <img src= "<?php echo $row['url']; ?>"  class="img-fluid rounded b-shadow-a" alt=<?php echo $row['alt']; ?>>                    </div>
                    <?php
                    }
                    ?>
                  </div>
                  <div class="col-sm-6 col-md-7">
                    <div class="about-info">
                      <p><span class="title-s">Name: </span> <span><b><br>Adriatic Boat Tours</b></span></p>
                      <p><span class="title-s">Email: </span> <span><b><i>adriaticboattours@gmail.com</i></b></span></p>
                      <p><span class="title-s">Phone: </span> <span><b><br>+385 99-471-3945</b></span></p>
                    </div>
                  </div>
                </div>
                
                
                <div class="skill-mf">
                  <p class="title-s"></p>
                  <span>Communicative staff</span> <span class="pull-right">100%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 100%;" aria-valuenow="85" aria-valuemin="0"
                      aria-valuemax="100"></div>
                  </div>
                  <span>Always available and ready to help</span> <span class="pull-right">100%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 100%" aria-valuenow="75" aria-valuemin="0"
                      aria-valuemax="100"></div>
                  </div>
                  <span>A company with experience</span> <span class="pull-right">100%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 100%" aria-valuenow="50" aria-valuemin="0"
                      aria-valuemax="100"></div>
                  </div>
                 
                </div>
              </div>
            
              <div class="col-md-6">
                <div class="about-me pt-4 pt-md-0">
                  <div class="title-box-2">
                    <h5 class="title-left">
                    <?php echo $array[0] ?><!--About us-->
                    </h5>
                  </div>
                  <?php
                    $sql = "SELECT * from tekst t 
                    WHERE t.position LIKE '%about-us%'
                    AND t.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
                  <p> <?php echo $row['paragraph']; ?>
                  </p>
                  
                <?php }  ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!--/ Section Services Star /-->
  
  <section id="service" class="services-mf route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
            <?php echo $array[1] ?><!--Our services-->
            </h3>
            <p class="subtitle-a">
              
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
      <div class="col-md-4">

          <div class="service-box">  
            <div class="service-ico">
            <?php
                    $sql = "SELECT * from photos p 
                    WHERE p.position LIKE '%services-adriatic%'
                    AND p.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
            <img src= "<?php echo $row['url']; ?>"  class="img-fluid rounded b-shadow-a" alt=<?php echo $row['alt']; ?>>
            <?php
                    }
                    ?>
            </div>
            <div class="service-content">
            <?php
                    $sql = "SELECT * from tekst t 
                    WHERE t.position LIKE '%services-adriatic%'
                    AND t.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <h2 class="s-title"><?php echo $row['heading']; ?><!--Adriatic--></h2>
              <p class="s-description text-center" ><?php echo $row['paragraph']; ?>
                </p>
                <button onclick="myFunction3()" id="myBtn3" style="position: absolute; left: 50%; transform: translateX(-50%);"><i>Read more</i></button>

                <script>
                    function myFunction3() {
                    var dots = document.getElementById("dots3");
                    var moreText = document.getElementById("more3");
                    var btnText = document.getElementById("myBtn3");

                    if (dots.style.display === "none") {
                        dots.style.display = "inline";
                        btnText.innerHTML = "Read more"; 
                        moreText.style.display = "none";
                  } else {
                        dots.style.display = "none";
                        btnText.innerHTML = "<i>Read less</i>"; 
                        moreText.style.display = "inline";
                        }
                    }
                </script>
               <?php
                    }
                    ?>  
            </div>
          </div>
         
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
            <?php
                    $sql = "SELECT * from photos p 
                    WHERE p.position LIKE '%services-cavetour%'
                    AND p.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <img src="<?php echo $row['url']; ?>"  class="img-fluid rounded b-shadow-a" alt=<?php echo $row['alt']; ?>>
              <?php
                    }
                    ?>
            </div>
            <div class="service-content">
            <?php
                    $sql = "SELECT * from tekst t 
                    WHERE t.position LIKE '%services-cavetour%'
                    AND t.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <h2 class="s-title"><?php echo $row['heading']; ?><!--Cave Tour--></h2>
              <p class="s-description text-center"><?php echo $row['paragraph']; ?>
                </p>
                
                <button onclick="myFunction2()" id="myBtn2" style="position: absolute; left: 50%; transform: translateX(-50%);"><i>Read more</i></button>
  
                <script>
                    function myFunction2() {
                    var dots = document.getElementById("dots2");
                    var moreText = document.getElementById("more2");
                    var btnText = document.getElementById("myBtn2");
  
                    if (dots.style.display === "none") {
                        dots.style.display = "inline";
                        btnText.innerHTML = "Read more"; 
                        moreText.style.display = "none";
                  } else {
                        dots.style.display = "none";
                        btnText.innerHTML = "<i>Read less</i>"; 
                        moreText.style.display = "inline";
                        }
                    }
                </script>
                <?php
                    }
                    ?>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
            <?php
                    $sql = "SELECT * from photos p 
                    WHERE p.position LIKE '%services-smallboat%'
                    AND p.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
                    <img src= "<?php echo $row['url']; ?>"  class="img-fluid rounded b-shadow-a" alt=<?php echo $row['alt']; ?>>              
                    <?php
                    }
                    ?>
            </div>

            <div class="service-content">
            <?php
                    $sql = "SELECT * from tekst t 
                    WHERE t.position LIKE '%services-smallboat%'
                    AND t.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <h2 class="s-title"><?php echo $row['heading']; ?><!--Small Boat--></h2>
              <p class="s-description text-center"><?php echo $row['paragraph']; ?>
              </p>
              <button onclick="myFunction()" id="myBtn" style="position: absolute; left: 50%; transform: translateX(-50%);"><i>Read more</i></button>

              <script>
                  function myFunction() {
                  var dots = document.getElementById("dots");
                  var moreText = document.getElementById("more");
                  var btnText = document.getElementById("myBtn");

                  if (dots.style.display === "none") {
                      dots.style.display = "inline";
                      btnText.innerHTML = "Read more"; 
                      moreText.style.display = "none";
                } else {
                      dots.style.display = "none";
                      btnText.innerHTML = "<i>Read less</i>"; 
                      moreText.style.display = "inline";
                      }
                  }
              </script>
              <?php
                    }
                    ?>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
            <?php
                    $sql = "SELECT * from photos p 
                    WHERE p.position LIKE '%services-jetski%'
                    AND p.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
                    <img src= "<?php echo $row['url']; ?>"  class="img-fluid rounded b-shadow-a" alt=<?php echo $row['alt']; ?>>
                    <?php
                    }
                    ?>
             </div>
            <div class="service-content">
            <?php
                    $sql = "SELECT * from tekst t 
                    WHERE t.position LIKE '%services-jetski%'
                    AND t.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <h2 class="s-title"><?php echo $row['heading']; ?><!--Jetski--></h2>
              <p class="s-description text-center"><?php echo $row['paragraph']; ?>
                </p>
                <button onclick="myFunction1()" id="myBtn1" style="position: absolute; left: 50%; transform: translateX(-50%);"><i>Read more</i></button>
  
                <script>
                    function myFunction1() {
                    var dots = document.getElementById("dots1");
                    var moreText = document.getElementById("more1");
                    var btnText = document.getElementById("myBtn1");
  
                    if (dots.style.display === "none") {
                        dots.style.display = "inline";
                        btnText.innerHTML = "Read more"; 
                        moreText.style.display = "none";
                  } else {
                        dots.style.display = "none";
                        btnText.innerHTML = "<i>Read less</i>"; 
                        moreText.style.display = "inline";
                        }
                    }
                </script>
              <?php
                    }
                    ?>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
            <?php
                    $sql = "SELECT * from photos p 
                    WHERE p.position LIKE '%services-kayak%'
                    AND p.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <img src="<?php echo $row['url']; ?>"  class="img-fluid rounded b-shadow-a" alt=<?php echo $row['alt']; ?>>
              <?php
                    }
                    ?>
            </div>
            <div class="service-content">
            <?php
                    $sql = "SELECT * from tekst t 
                    WHERE t.position LIKE '%services-kayak%'
                    AND t.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <h2 class="s-title"><?php echo $row['heading']; ?><!--Kayak--></h2>
              <p class="s-description text-center"><?php echo $row['paragraph']; ?>
               
              </p>
              <?php
                    }
                    ?>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
            <?php
                    $sql = "SELECT * from photos p 
                    WHERE p.position LIKE '%services-supboard%'
                    AND p.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <img src="<?php echo $row['url']; ?>"  class="img-fluid rounded b-shadow-a" alt=<?php echo $row['alt']; ?>>
              <?php
                    }
                    ?>
            </div>
            <div class="service-content">
            <?php
                    $sql = "SELECT * from tekst t 
                    WHERE t.position LIKE '%services-supboard%'
                    AND t.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <h2 class="s-title"><?php echo $row['heading']; ?><!--Sup board--></h2>
              <p class="s-description text-center"><?php echo $row['paragraph']; ?>
                
              </p>
              <?php
                    }
                    ?>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box ">
            <div class="service-ico">
            <?php
                    $sql = "SELECT * from photos p 
                    WHERE p.position LIKE '%services-sunsettour%'
                    AND p.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <img src="<?php echo $row['url']; ?>"  class="img-fluid rounded b-shadow-a" alt=<?php echo $row['alt']; ?>>
              <?php
                    }
                    ?>
            </div>
            <div class="service-content">
            <?php
                    $sql = "SELECT * from tekst t 
                    WHERE t.position LIKE '%services-sunsettour%'
                    AND t.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <h2 class="s-title"><?php echo $row['heading']; ?><!--SUNSET TOUR--></h2>
              <p class="s-description text-center"><?php echo $row['paragraph']; ?>
                </p>
                <button onclick="myFunction4()" id="myBtn4" style="position: absolute; left: 50%; transform: translateX(-50%);"><i>Read more</i></button>
                
                <script>
                    function myFunction4() {
                    var dots = document.getElementById("dots4");
                    var moreText = document.getElementById("more4");
                    var btnText = document.getElementById("myBtn4");
  
                    if (dots.style.display === "none") {
                        dots.style.display = "inline";
                        btnText.innerHTML = "Read more"; 
                        moreText.style.display = "none";
                  } else {
                        dots.style.display = "none";
                        btnText.innerHTML = "<i>Read less</i>"; 
                        moreText.style.display = "inline";
                        }
                    }
                </script>
                <?php
                    }
                    ?>
             </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
          <div class="service-ico">
        <?php
                    $sql = "SELECT * from photos p 
                    WHERE p.position LIKE '%services-speedboat%'
                    AND p.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
            
            <img src= "<?php echo $row['url']; ?>"  class="img-fluid rounded b-shadow-a" alt=<?php echo $row['alt']; ?>>
            <?php
                    }
                    ?>
            </div>
            <div class="service-content">
            <?php
                    $sql = "SELECT * from tekst t 
                    WHERE t.position LIKE '%services-speedboat%'
                    AND t.visible = '1';" ;
                    
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($result)){
                    ?>
              <h2 class="s-title"><?php echo $row['heading']; ?><!--Speed Boat Tour--></h2>
              <p class="s-description text-center"><?php echo $row['paragraph']; ?>
                </p>
               <button onclick="myFunction5()" id="myBtn5" style="position: absolute; left: 50%; transform: translateX(-50%);"><i>Read more</i></button>
               
                <script>
                    function myFunction5() {
                    var dots = document.getElementById("dots5");
                    var moreText = document.getElementById("more5");
                    var btnText = document.getElementById("myBtn5");
  
                    if (dots.style.display === "none") {
                        dots.style.display = "inline";
                        btnText.innerHTML = "Read more"; 
                        moreText.style.display = "none";
                  } else {
                        dots.style.display = "none";
                        btnText.innerHTML = "<i>Read less</i>"; 
                        moreText.style.display = "inline";
                        }
                    }
                </script>
                <?php
                    }
                    ?>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </section>
  <!--/ Section Services End /-->
<!--
  <div class="section-counter paralax-mf bg-image" style="background-image: url(img/counters-bg.jpg)">
    <div class="overlay-mf"></div>
    <div class="container">
      <div class="row">
        <div class="col-sm-3 col-lg-3">
          <div class="counter-box">
            <div class="counter-ico">
              <span class="ico-circle"><i class="ion-checkmark-round"></i></span>
            </div>
            <div class="counter-num">
              <p class="counter">450</p>
              <span class="counter-text">WORKS COMPLETED</span>
            </div>
          </div>
        </div>
        <div class="col-sm-3 col-lg-3">
          <div class="counter-box pt-4 pt-md-0">
            <div class="counter-ico">
              <span class="ico-circle"><i class="ion-ios-calendar-outline"></i></span>
            </div>
            <div class="counter-num">
              <p class="counter">15</p>
              <span class="counter-text">YEARS OF EXPERIENCE</span>
            </div>
          </div>
        </div>
        <div class="col-sm-3 col-lg-3">
          <div class="counter-box pt-4 pt-md-0">
            <div class="counter-ico">
              <span class="ico-circle"><i class="ion-ios-people"></i></span>
            </div>
            <div class="counter-num">
              <p class="counter">550</p>
              <span class="counter-text">TOTAL CLIENTS</span>
            </div>
          </div>
        </div>
        <div class="col-sm-3 col-lg-3">
          <div class="counter-box pt-4 pt-md-0">
            <div class="counter-ico">
              <span class="ico-circle"><i class="ion-ribbon-a"></i></span>
            </div>
            <div class="counter-num">
              <p class="counter">36</p>
              <span class="counter-text">AWARD WON</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
-->

  <!--/ Section Portfolio Star /-->
  <section id="work" class="portfolio-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
            <?php echo $array[2] ?><!--Images-->
            </h3>
            <p class="subtitle-a">
              
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="work-box">
             <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
              <!--
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title"></h2>
                    <div class="w-more">
                      <span class="w-ctegory"></span>  <span class="w-date"></span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            -->
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija1' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
                <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">               <div class="work-img">
                <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
              <!--
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Loreda Cuno Nere</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            -->
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija2' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
              <!--
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Mavrito Lana Dere</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            -->
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija3' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
              <!--
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Bindo Laro Cado</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            -->
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija4' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
              <!--
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Studio Lena Mado</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            -->
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija5' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
              <!--
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Studio Big Bang</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2017</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            -->
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija6' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
              <!--
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Bindo Laro Cado</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            -->
            </a>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija7' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
              <!--
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Bindo Laro Cado</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            -->
            </a>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija8' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
             <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
              <!--
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Bindo Laro Cado</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            -->
            </a>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija9' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
            </a>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija10' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
          <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
            </a>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija11' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija12' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
            </a>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija13' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
            </a>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <?php
    
                $sql = "SELECT * FROM photos
                WHERE position='galerija14' 
                AND visible=1" ;
                    
                $result = mysqli_query($con, $sql);
                while($row = mysqli_fetch_array($result)){
                ?>
            <a href="<?php echo $row['url']; ?>" alt=<?php echo $row['alt']; ?> data-lightbox="gallery-mf">
              <div class="work-img">
              <img src="<?php echo $row['url']; ?>"  class="img-fluid" alt=<?php echo $row['alt']; ?>>
              </div>
              <?php
                    }
                    ?>
            </a>
          </div>
        </div>



      </div>
    </div>
  </section>
  <!--/ Section Portfolio End /-->

  <!--/ Section Find Us Star /-->
  <section id="findus" class="portfolio-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
            <?php echo $array[3] ?><!--Find Us-->
            </h3>
            <p class="subtitle-a">
              
            </p>
            
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <p>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2932.112383738381!2d18.036667715333806!3d42.70134107916543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x134b8a7a63a2ec7d%3A0xd96b63ff439d7567!2sMahovo%2033%2C%2020235%2C%20Zaton!5e0!3m2!1sen!2shr!4v1650571034923!5m2!1sen!2shr" width="100%" height="500" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    
      </p>
    </section>


  <!--/ Section Testimonials Star /-->
  <!--
  <div class="testimonials paralax-mf bg-image" style="background-image: url(img/naslovna.jpeg)">
    <div class="overlay-mf"></div>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div id="testimonial-mf" class="owl-carousel owl-theme">
            <div class="testimonial-box">
              <div class="author-test">
                <img src="img/testimonial-2.jpg" alt="" class="rounded-circle b-shadow-a">
                <span class="author">Xavi Alonso</span>
              </div>
              <div class="content-test">
                <p class="description lead">
                  Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Lorem ipsum dolor sit amet,
                  consectetur adipiscing elit.
                </p>
                <span class="comit"><i class="fa fa-quote-right"></i></span>
              </div>
            </div>
            <div class="testimonial-box">
              <div class="author-test">
                <img src="img/testimonial-4.jpg" alt="" class="rounded-circle b-shadow-a">
                <span class="author">Marta Socrate</span>
              </div>
              <div class="content-test">
                <p class="description lead">
                  Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Lorem ipsum dolor sit amet,
                  consectetur adipiscing elit.
                </p>
                <span class="comit"><i class="fa fa-quote-right"></i></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
-->

  <!--/ Section find us /-->
  <!--
  <section id="findus" class="blog-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              Find Us
            </h3>
            <p class="subtitle-a">
              
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      
      <div class="row">
        
        <div class="col-md-4">
         
          <div class="card card-blog">
            <div class="card-img">
              <a href="blog-single.html"><img src="img/post-1.jpg" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category">Travel</h6>
                </div>
              </div>
              <h3 class="card-title"><a href="blog-single.html">See more ideas about Travel</a></h3>
              <p class="card-description">
                Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Praesent sapien massa, convallis
                a pellentesque nec,
                egestas non nisi.
              </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="#">
                  <img src="img/testimonial-2.jpg" alt="" class="avatar rounded-circle">
                  <span class="author">Morgan Freeman</span>
                </a>
              </div>
              <div class="post-date">
                <span class="ion-ios-clock-outline"></span> 10 min
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-blog">
            <div class="card-img">
              <a href="blog-single.html"><img src="img/post-2.jpg" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category">Web Design</h6>
                </div>
              </div>
              <h3 class="card-title"><a href="blog-single.html">See more ideas about Travel</a></h3>
              <p class="card-description">
                Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Praesent sapien massa, convallis
                a pellentesque nec,
                egestas non nisi.
              </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="#">
                  <img src="img/testimonial-2.jpg" alt="" class="avatar rounded-circle">
                  <span class="author">Morgan Freeman</span>
                </a>
              </div>
              <div class="post-date">
                <span class="ion-ios-clock-outline"></span> 10 min
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-blog">
            <div class="card-img">
              <a href="blog-single.html"><img src="img/post-3.jpg" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category">Web Design</h6>
                </div>
              </div>
              <h3 class="card-title"><a href="blog-single.html">See more ideas about Travel</a></h3>
              <p class="card-description">
                Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Praesent sapien massa, convallis
                a pellentesque nec,
                egestas non nisi.
              </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="#">
                  <img src="img/testimonial-2.jpg" alt="" class="avatar rounded-circle">
                  <span class="author">Morgan Freeman</span>
                </a>
              </div>
              <div class="post-date">
                <span class="ion-ios-clock-outline"></span> 10 min
              </div>
            </div>
          </div>
        </div>
      
      </div>
    </div>
  </section>
-->
  <!--/ Section Blog End /-->

  <?php
include_once 'header-footer/footer.php';
?>
</body>
</html>
