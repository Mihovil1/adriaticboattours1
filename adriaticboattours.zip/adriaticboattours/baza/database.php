<?php
$servername = "localhost";
$username = "adriat13";
$password = "W4f7zvJq65";
$db = "adriat13_adriaticboattours";

// Create connection
$con = mysqli_connect($servername,$username,$password,$db);
$con->set_charset('utf8mb4');
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
  }